# Simple Cipher Program

This program encrypts any input text into machine code. That's it lol
